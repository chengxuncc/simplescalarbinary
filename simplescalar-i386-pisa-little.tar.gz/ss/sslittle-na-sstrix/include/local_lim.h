/* Implementation-specific limits.
   Generated at Thu Aug  3 15:48:44 1995.  */

#define ARG_MAX 20480
#define OPEN_MAX 64
#define MAX_CANON 256
#define NAME_MAX 255
#define PATH_MAX 1024
