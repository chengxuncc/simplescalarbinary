/*
 * structure to access an
 * integer in bytes
 */
struct
{
	char	lobyte;
	char	hibyte;
};

/*
 * structure to access an integer
 */
struct
{
	int	integ;
};

/*
 * structure to access a long as integers
 */
struct {
	int	loword;
	int	hiword;
};

/*
 *	structure to access an unsigned
 */
struct {
	unsigned	unsignd;
};
