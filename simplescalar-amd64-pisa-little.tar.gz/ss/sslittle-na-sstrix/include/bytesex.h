#define __BYTE_ORDER 1234
